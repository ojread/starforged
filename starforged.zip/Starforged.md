---
name: Starforged
ironvault:
  playset:
    type: registry
    key: starforged
  customContentFolder: Custom Content
iron-vault-kind: campaign

---

Welcome to your new campaign! This is a campaign index file, which marks its folder as a campaign. Any journals or game entities inside this folder will use this campaign for any mechanics or commands. You can replace all this text with any details or notes you have about your campaign. As long as the file properties remain the same, you don't have to worry about the contents of this file.
