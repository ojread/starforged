| Name                  | Ebon Suns                                                                 |
| --------------------- | ------------------------------------------------------------------------- |
| Faction Type          | [Fringe Group](datasworn:oracle_rollable:starforged/faction/fringe_group) |
| Faction Name Template | Ebon Suns                                                                 |
| Fringe Group          | Scavengers                                                                |
