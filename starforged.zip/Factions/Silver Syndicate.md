| Name                  | Silver Syndicate                                                  |
| --------------------- | ----------------------------------------------------------------- |
| Faction Type          | [Dominion](datasworn:oracle_rollable:starforged/faction/dominion) |
| Faction Name Template | Silver Syndicate                                                  |
| Dominion              | Commerce                                                          |
| Dominion: Leadership  | Disputed leadership                                               |
