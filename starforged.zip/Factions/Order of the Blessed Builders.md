| Name | Order of the Blessed Builders |
| ---  | --- |
| Faction Type |  [Guild](datasworn:oracle_rollable:starforged/faction/guild)  |
| Faction Name Template |  Order of the Blessed Builders  |
| Guild |  Engineers  |
