---
name: Curtis Nadir
xp_spent: 0
xp_added: 0
momentum: 2
edge: 0
heart: 0
iron: 0
shadow: 0
wits: 0
health: 5
spirit: 5
supply: 5
Quests_Progress: 0
Quests_XPEarned: 0
Bonds_Progress: 0
Bonds_XPEarned: 0
Discoveries_Progress: 0
Discoveries_XPEarned: 0
iron-vault-kind: character
callsign: Rook
---


```iron-vault-character-info
```

```iron-vault-character-stats
```

```iron-vault-character-meters
```

```iron-vault-character-special-tracks
```

```iron-vault-character-impacts
```

```iron-vault-character-assets
```

